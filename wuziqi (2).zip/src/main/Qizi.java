package main;

import common.ImageValue;

import java.awt.*;

//棋子类
public class Qizi {
    private int x = 0;//x坐标
    private int y = 0;//y坐标
    private int h = 36;//高



    private int type = 1;//1,白棋，2，黑棋。
    private boolean last = false; //是否是最后一个棋子

    public Qizi(int x,int y,int type){
        this.x = x;
        this.y = y;
        this.type = type;
    }
    //图片绘制方法
    public void draw(Graphics g){
        if(type == 1){
            g.drawImage(ImageValue.Whiteimage,x-h/2,y-h/2,h,h,null);
        }else if(type == 2){
            g.drawImage(ImageValue.Blackimage, x-h/2,y-h/2,h,h,null);

        }
        if(last){//判断最后一步
            Graphics2D g2d = (Graphics2D) g;
            g2d.setStroke(new BasicStroke(1.6f));

            g2d.drawRect(x-2,y-2,6,6);
        }
    }
    //lsat get set
    public boolean isLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }
    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

}
