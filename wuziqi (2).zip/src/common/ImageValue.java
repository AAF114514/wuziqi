package common;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

//图片加载
public class ImageValue {
    public  static BufferedImage Whiteimage=null;
    public  static BufferedImage Blackimage=null;
    //图片路径
    private static String path = "/Image/";
    //初始化
    public static void init(){
        try {
            Whiteimage = ImageIO.read(ImageValue.class.getResource(path+"niubi2.jpg"));
            Blackimage = ImageIO.read(ImageValue.class.getResource(path+"niubi1.jpg"));


        }catch (Exception e) {
           // e.printStackTrace();
            System.out.println("mm");
        }
    }



}
