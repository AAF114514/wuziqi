package main;

public class main {
    public static void main(String args[]){
        GameFrame frame= new GameFrame();//启动实例
        GamePanel panel= new GamePanel(frame);
        frame.add(panel);//添加窗体
        frame.setVisible(true);


    }
}
