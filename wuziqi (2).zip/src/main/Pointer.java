package main;

import java.awt.*;

//指示器类
public class Pointer {
    private int i = 0;//二维数组下标i
    private int j = 0;//二维数组下标j
    private int x = 0;
    private int y = 0;
    private int h = 32;
    private boolean isShow = false;
    private int type = 0;//0没棋子，1白2黑
    public Pointer(int i, int j, int x, int y) {

        this.i = i;
        this.j = j;
        this.x = x;
        this.y = y;

    }

    //绘制指示器方法
    public void draw(Graphics g) {
        g.setColor(new Color(255, 0, 0));
        if (isShow) {
            //g.drawRect(x-h/2,y-h/2,h,h);//绘制方形
            //绘制指示器样式
            drawPointer(g);
        }


    }

    //绘制方法
    private void drawPointer(Graphics g) {
        //转换2d 画笔
        Graphics2D g2d = (Graphics2D) g;
        //设置粗细
        g2d.setStroke(new BasicStroke(2.0f));
        //左上角
        int x1 = 0;
        int y1 = 0;
        int x2 = 0;
        int y2 = 0;
        //横向
        x1 = this.x - h / 2;
        y1 = this.y - h / 2;
        y2 = y1;
        x2 = x1 + h / 4;
        g2d.drawLine(x1, y1, x2, y2);
        //纵向
        x1 = this.x - h / 2;
        y1 = this.y - h / 2;
        y2 = y1 + h / 4;
        x2 = x1;
        g2d.drawLine(x1, y1, x2, y2);
        //右上角
        x1 = this.x + h / 2;
        y1 = this.y - h / 2;
        //横向
        y2 = y1;
        x2 = x1 - h / 4;
        g2d.drawLine(x1, y1, x2, y2);
        //纵向
        y2 = y1 + h / 4;
        x2 = x1;
        g2d.drawLine(x1, y1, x2, y2);
        //右下角
        x1 = this.x + h / 2;
        y1 = this.y + h / 2;
        //横向
        x2 = x1 - h / 4;
        y2 = y1;
        g2d.drawLine(x1, y1, x2, y2);
        //纵向
        x2 = x1;
        y2 = y1 - h / 4;
        g2d.drawLine(x1, y1, x2, y2);
        //左下角
        x1 = this.x - h / 2;
        y1 = this.y + h / 2;
        //横向
        x2 = x1 + h / 4;
        y2 = y1;
        g2d.drawLine(x1, y1, x2, y2);
        //纵向
        x2 = x1;
        y2 = y1 - h / 4;
        g2d.drawLine(x1, y1, x2, y2);


    }

    //判断是否在指示器范围内
    public boolean isPoint(int x, int y) {
        //方形区域
        int x1 = this.x - h / 2;
        int y1 = this.y - h / 2;
        int x2 = this.x + h / 2;
        int y2 = this.y + h / 2;

        return x > x1 && y > y1 && x < x2 && y < y2;


    }

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean isShow) {
        this.isShow = isShow;
    }

    //x的get set
    public void setX(int x) {
        this.x = x;
    }

    public int getX() {
        return x;
    }
    //y的get set
    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    //type get set
    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }
}