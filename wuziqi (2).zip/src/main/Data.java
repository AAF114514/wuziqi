package main;
//返回结果
public class Data {
    private int count = 0;//权重分数
    private int i = 0;//下标

    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }

    private int j = 0;//下标


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
}
