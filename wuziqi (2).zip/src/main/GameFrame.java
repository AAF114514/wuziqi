package main;

import javax.swing.JFrame;
import java.awt.*;

//窗体类
public class GameFrame extends JFrame{
    //构造
    public GameFrame(){
        setTitle("五子棋大战");//标题
        setSize(620,670);//size
        getContentPane().setBackground(new Color(209,146,17));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭退出
        setLocationRelativeTo(null);//剧中
        setResizable(false);//不允许变大变小
       // setVisible(true);//显示
    }
}
