package main;

import common.ImageValue;
import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;
import java.util.List;

//画布类
public class GamePanel extends JPanel implements ActionListener{
    private GamePanel panel = null;
    private JMenuBar jmb = null;
    private GameFrame mainFrame = null;
    public final int ROWS = 15;
    public final int CLOS = 15;
    private String gameFlag = "start_man";//游戏状态
    public Pointer [][] pointers = new Pointer[ROWS][CLOS];//数组创建
    //存棋子集合
    public List<Qizi> qizis = new ArrayList<Qizi>();
   public int te = 1;

    //构造
    public GamePanel(GameFrame mainFrame)
    {
        System.out.println("gouzao");
        this.setLayout(null);
        this.setOpaque(false);//防止背景覆盖
        this.mainFrame = mainFrame;
        this.panel = this;
        //图片加载
        ImageValue.init();
        //创建菜单
        creatMnue();
        //创建鼠标监听
        System.out.println("....."+gameFlag);
        if("start_man".equals(gameFlag)){
            createMouseListener1();
            System.out.println("zhixonh");
           // System.out.println("jj");
        }else{
           // System.out.println("jjjjjj");
            //System.out.println("..."+gameFlag);
            createMouseListener();
        }

        //创建数组内容
        creatPointers();
    }
    void reset(){
        if("start_man".equals(gameFlag)){
            createMouseListener1();
            //System.out.println("zhixonh");
            // System.out.println("jj");
        }else{
            // System.out.println("jjjjjj");
            //System.out.println("..."+gameFlag);
            createMouseListener();
        }
    }

    //数组内容
    private void creatPointers() {

        Pointer pointer;
        int x = 0,y = 0;
        int start = 26;
        for(int i=0;i<ROWS;i++)
        {
            for(int j=0;j<ROWS;j++)
            {
                x = j*40+start;
                y = i*40+start;
                pointer = new Pointer(i,j,x,y);
                pointers [i][j] = pointer;
            }
        }
    }
    //清理之前的标记
    private void clearAILast() {
        Qizi qizi;
        for(int i=0;i<qizis.size();i++)
        {
            qizi = qizis.get(i);
            if(qizi!=null&&qizi.getType()==1){
                qizi.setLast(false);
            }
        }

    }

    //鼠标监听
    private void createMouseListener() {
        MouseAdapter mouseAdapter = new MouseAdapter() {

            @Override//click事件
            public void mouseClicked(MouseEvent e) {
                if(!"start".equals(gameFlag)) return;//flag判断是否发生
                Pointer pointer;
                //获取鼠标坐标
                int x = e.getX();
                int y = e.getY();
                //循环指示器的二维数组
                for(int i=0;i<ROWS;i++)
                {
                    for(int j=0;j<ROWS;j++)
                    {
                        //得到每一个指示器对象
                        pointer =pointers [i][j] ;
                        if(pointer.isPoint(x,y) && pointer.getType() == 0){
                           Qizi qizi = new Qizi(pointer.getX(),pointer.getY(),2);
                           qizis.add(qizi);
                           pointer.setType(2);//被黑棋占用
                           //重绘
                            repaint();
                            clearAILast();
                            //AI走棋子

                            if(AI.has5(pointer,panel)){//你已经连成功了
                                gameWin();
                            }else{
                                AI.next(panel);
                            }
                            return;
                        }

                    }
                }

            }

            @Override//move事件
            public void mouseMoved(MouseEvent e) {
                if(!"start".equals(gameFlag)) return;//flag判断是否发生
                Pointer pointer;
                //获取鼠标坐标
                int x = e.getX();
                int y = e.getY();
                //循环指示器的二维数组
                for(int i=0;i<14;i++)
                {
                    for(int j=0;j<14;j++)
                    {
                        //得到每一个指示器对象
                        pointer =pointers [i][j] ;
                        if(pointer.isPoint(x,y) && pointer.getType() == 0){
                            pointer.setShow(true);
                        }
                        else{
                            pointer.setShow(false);
                        }
                    }
                }
                //System.out.println("mouse_move");
                //重绘
                repaint();
            }
        };

        addMouseMotionListener(mouseAdapter);
        addMouseListener(mouseAdapter);

    }
    private void createMouseListener1() {
        MouseAdapter mouseAdapter = new MouseAdapter() {

            @Override//click事件

            public void mouseClicked(MouseEvent e) {
                //System.out.println("jj");
                if(!"start_man".equals(gameFlag)) return;//flag判断是否发生
                Pointer pointer;
                //获取鼠标坐标
                int x = e.getX();
                int y = e.getY();
                //循环指示器的二维数组int fl = 1;
                for(int i=0;i<ROWS;i++)
                {
                    for(int j=0;j<ROWS;j++)
                    {
                        //得到每一个指示器对象
                        pointer =pointers [i][j] ;
                        if(pointer.isPoint(x,y) && pointer.getType() == 0){
                            {
                                if(te  == 1){
                                    Qizi qizi = new Qizi(pointer.getX(),pointer.getY(),1);
                                    qizis.add(qizi);
                                    pointer.setType(1);//被黑棋占用
                                    //System.out.println("hh1");
                                    if(AI.has5_w(pointer,panel)){//你已经连成功了
                                        gameWin_w();
                                    }
                                    te = -te;
                                }else if(te == -1){
                                    Qizi qizi = new Qizi(pointer.getX(),pointer.getY(),2);
                                    qizis.add(qizi);
                                    pointer.setType(2);//被黑棋占用
                                    //System.out.println("hh1");
                                    te = -te;
                                    if(AI.has5_w(pointer,panel)){//你已经连成功了
                                        gameWin_w();
                                    }
                                    else if(AI.has5_b(pointer,panel)){//你已经连成功了
                                        gameWin_b();
                                    }
                                }


                               // System.out.println("heiqi");

                            }
                            repaint();

                            //重绘

                           // clearAILast();
                            //AI不走棋子
                            return;
                        }
                    }
                }
            }

            @Override//move事件
            public void mouseMoved(MouseEvent e) {
                if(!"start_man".equals(gameFlag)) return;//flag判断是否发生
                Pointer pointer;
                //获取鼠标坐标
                int x = e.getX();
                int y = e.getY();
                //循环指示器的二维数组
                for(int i=0;i<14;i++)
                {
                    for(int j=0;j<14;j++)
                    {
                        //得到每一个指示器对象
                        pointer =pointers [i][j] ;
                        if(pointer.isPoint(x,y) && pointer.getType() == 0){
                            pointer.setShow(true);
                        }
                        else{
                            pointer.setShow(false);
                        }
                    }
                }
                //System.out.println("mouse_move");
                //重绘
                repaint();
            }
        };
        addMouseMotionListener(mouseAdapter);
        addMouseListener(mouseAdapter);

    }

    //绘图
    public void paint(Graphics g){
        super.paint(g);
        //绘制网格
        drawGrid(g);
        //绘制中心5个小黑点
        draw5Point(g);
        //绘制
        drawPointer(g);
        //绘制棋子
        drawQizi(g);
    }
    //绘制棋子方法
    private void drawQizi(Graphics g) {
        Qizi qizi;
        for(int i=0;i< qizis.size();i++){
            qizi = qizis.get(i);
            qizi.draw(g);
        }
    }

    //绘制鼠标小方框
    private void drawPointer(Graphics g) {
        Pointer pointer;

        for(int i=0;i<ROWS;i++)
        {
            for(int j=0;j<ROWS;j++)
            {
               pointer = pointers [i][j];
               if(pointer!=null){
                   pointer.draw(g);
               }
            }
        }
    }

    //绘制5个点
    private void draw5Point(Graphics g) {
        int x = 142;
        int y = 142;
        g.fillArc(x,y,8,8,0,360);
        x = 462;
        g.fillArc(x,y,8,8,0,360);
        y = 462;
        g.fillArc(x,y,8,8,0,360);
        x = 142;
        g.fillArc(x,y,8,8,0,360);
        x = 302;y=302;
        g.fillArc(x,y,8,8,0,360);
    }
    //绘制线
    private void drawGrid(Graphics g) {
        int x1 = 26,y1 = 26,x2 = 586,y2 = 26;
        int dis = 40;
        //绘制15条横向线
        int start = 26;
        for(int i=0;i < 15;i++){
            y1 = i * dis + start;
            y2 = y1;
            g.drawLine(x1,y1,x2,y2);
        }
        //15条竖向线
        y1=26;y2=586;
        for(int i=0;i < 15;i++){
            x1 = i * dis + start;
            x2 = x1;
            g.drawLine(x1,y1,x2,y2);
        }

    }


    //菜单创建
    private Font createFont(){
        return new Font("微软雅黑",Font.BOLD,18);
    }//字体设置


    private void creatMnue() {
        //创建jmb
        jmb = new JMenuBar();

        Font tfont = createFont();//字体取得
        //jme1,2为游戏选项。
        JMenu jMenu1 = new JMenu("游戏");
        jMenu1.setFont(createFont());
        JMenu jMenu2 = new JMenu("帮助");
        jMenu2.setFont(createFont());

        JMenuItem jmi1 = new JMenuItem("人机对战");
        JMenuItem jmi5 = new JMenuItem("双人对战");

        jmi1.setFont(tfont);
        JMenuItem jmi2 = new JMenuItem("退出");//创建子菜单
        jmi2.setFont(tfont);//字体
        jmi5.setFont(tfont);

        JMenuItem jmi3 = new JMenuItem("操作帮助");
        jmi3.setFont(tfont);
        JMenuItem jmi4 = new JMenuItem("胜利条件");
        jmi4.setFont(tfont);//字体

        jMenu1.add(jmi1);
        jMenu1.add(jmi5);
        jMenu1.add(jmi2);//添加子菜单1，2

        jMenu2.add(jmi3);
        jMenu2.add(jmi4);//添加子菜单3，4


        jmb.add(jMenu1);
        jmb.add(jMenu2);//添加菜单1，2

        mainFrame.setJMenuBar(jmb);

        //添加监听
        jmi1.addActionListener( this);
        jmi2.addActionListener( this);
        jmi3.addActionListener( this);
        jmi4.addActionListener( this);
        jmi5.addActionListener( this);
        //设置指令
        jmi1.setActionCommand("restart");
        jmi2.setActionCommand("exit");
        jmi3.setActionCommand("help");
        jmi4.setActionCommand("win");
        jmi5.setActionCommand("restart_man");


    }

    @Override
    public void actionPerformed(ActionEvent e) {
       // System.out.println("菜单子项被点击");
        String command = e.getActionCommand();
        System.out.println(command);
        UIManager.put("OptionPane.buttonFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        UIManager.put("OptionPane.messageFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        if("exit".equals(command)){
            Object [] options = {
                    "确定","取消"
            };
            int response = JOptionPane.showConfirmDialog(this,"你真的要退出吗？呜呜");
            if(response == 0){
                System.exit(0);

            }
        }else if("restart".equals(command)){
//            if(!"end".equals(gameFlag)){
//                JOptionPane.showMessageDialog(null,"正在游戏中，无法重新开始！","提示",JOptionPane.INFORMATION_MESSAGE);
//            }else{
//                restart();
//            }
            restart();
        }else if("restart_man".equals(command)){
//            if(!"end".equals(gameFlag)){
//                JOptionPane.showMessageDialog(null,"正在游戏中，无法重新开始！","提示",JOptionPane.INFORMATION_MESSAGE);
//            }else{
//                restart_man();
//            }
            restart_man();

        }else if("help".equals(command)){
            JOptionPane.showMessageDialog(null,"鼠标在红色区域内落子！","提示",JOptionPane.INFORMATION_MESSAGE);

        }else if("win".equals(command)){
            JOptionPane.showMessageDialog(null,"五个棋子连一起就win了","提示",JOptionPane.INFORMATION_MESSAGE);
        }
    }

     void restart_man() {

            //重置数据
            //游戏状态
            //指示器
            //棋子
            gameFlag="start_man";
             //System.out.println("++"+gameFlag);
            Pointer pointer;
            for(int i=0;i<ROWS;i++){
                for(int j=0;j<CLOS;j++){
                    pointer = pointers[i][j];
                    pointer.setType(0);
                    pointer.setShow(false);
                }
            }

            qizis.clear();
            System.out.println("over" );
            reset();


    }

    void restart() {
        //重置数据
        //游戏状态
        //指示器
        //棋子
        gameFlag="start";
        System.out.println("++"+gameFlag);
        Pointer pointer;
        for(int i=0;i<ROWS;i++){
            for(int j=0;j<CLOS;j++){
                pointer = pointers[i][j];
                pointer.setType(0);
                pointer.setShow(false);
            }
        }

        qizis.clear();
       reset();

    }


    public void gameWin() {
        gameFlag = "end";
        UIManager.put("OptionPane.buttonFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        UIManager.put("OptionPane.messageFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        JOptionPane.showConfirmDialog(mainFrame,"恭喜你，你赢了！哈哈哈");

    }
    public void gameWin_w() {
        gameFlag = "end";
        UIManager.put("OptionPane.buttonFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        UIManager.put("OptionPane.messageFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        JOptionPane.showConfirmDialog(mainFrame,"你赢了！");

    }
    public void gameWin_b() {
        gameFlag = "end";
        UIManager.put("OptionPane.buttonFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        UIManager.put("OptionPane.messageFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        JOptionPane.showConfirmDialog(mainFrame,"你赢了！");

    }
    public void gameOver(){
        gameFlag = "end";
        UIManager.put("OptionPane.buttonFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        UIManager.put("OptionPane.messageFont",new FontUIResource(new Font("微软雅黑",Font.ITALIC,18)));
        JOptionPane.showConfirmDialog(mainFrame,"你终究不敌AI，在工大再学几年吧！");
    }
}
