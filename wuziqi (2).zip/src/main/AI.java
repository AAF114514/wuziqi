package main;

import javax.swing.*;
import java.util.*;

//电脑落子
public class AI {
    public static boolean next(GamePanel panel){
       boolean flag = go(panel) || louziRandom(panel);
        return flag;
    }
    //判断五子连珠
    static boolean has5(Pointer pointer1,GamePanel panel){
        List<Data> datas = new ArrayList<Data>();
        Pointer pointer;
        for(int i=0;i<panel.ROWS;i++){
            for(int j=0;j<panel.CLOS;j++){
                pointer = panel.pointers[i][j];
                if(pointer==null)continue;;
                if(pointer.getType() == 0){
                    continue;
                }
                if(pointer.getType() != pointer1.getType())continue;
                //循环四个方向
                int dir = 1;
                for(int k=1;k<=4;k++){
                    dir = k;
                    Data data = getData(dir,1,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                    data = getData(dir,1,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                }
            }
        }
        Collections.sort(datas,new DataCount());
        if(datas.size()>0){
            Data data = datas.get(0);
            if(data.getCount() == 100){
                return true;
            }
        }
        return false;
    }
    static boolean has5_w(Pointer pointer1,GamePanel panel){
        List<Data> datas = new ArrayList<Data>();
        Pointer pointer;
        for(int i=0;i<panel.ROWS;i++){
            for(int j=0;j<panel.CLOS;j++){
                pointer = panel.pointers[i][j];
                if(pointer==null)continue;;
                if(pointer.getType() == 0){
                    continue;
                }
                if(pointer.getType() != pointer1.getType())continue;
                //循环四个方向
                int dir = 1;
                for(int k=1;k<=4;k++){
                    dir = k;
                    Data data = getData(dir,1,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                    data = getData(dir,1,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                }
            }
        }
        Collections.sort(datas,new DataCount());
        if(datas.size()>0){
            Data data = datas.get(0);
            if(data.getCount() == 100){
                return true;
            }
        }
        return false;
    }
    static boolean has5_b(Pointer pointer1,GamePanel panel){
        List<Data> datas = new ArrayList<Data>();
        Pointer pointer;
        for(int i=0;i<panel.ROWS;i++){
            for(int j=0;j<panel.CLOS;j++){
                pointer = panel.pointers[i][j];
                if(pointer==null)continue;;
                if(pointer.getType() == 0){
                    continue;
                }
                if(pointer.getType() != pointer1.getType())continue;
                //循环四个方向
                int dir = 1;
                for(int k=1;k<=4;k++){
                    dir = k;
                    Data data = getData(dir,1,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                    data = getData(dir,1,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                }
            }
        }
        Collections.sort(datas,new DataCount());
        if(datas.size()>0){
            Data data = datas.get(0);
            if(data.getCount() == 100){
                return true;
            }
        }
        return false;
    }
    static boolean has5_wh(Pointer pointer1,GamePanel panel){
        List<Data> datas = new ArrayList<Data>();
        Pointer pointer;
        for(int i=0;i<panel.ROWS;i++){
            for(int j=0;j<panel.CLOS;j++){
                pointer = panel.pointers[i][j];
                if(pointer==null)continue;;
                if(pointer.getType() == 0){
                    continue;
                }
                if(pointer.getType() != pointer1.getType())continue;
                //循环四个方向
                int dir = 1;
                for(int k=1;k<=4;k++){
                    dir = k;
                    Data data = getData(dir,2,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                    data = getData(dir,2,panel,pointer);
                    if(data.getCount()!=-1&&data.getCount()!=0){
                        datas.add(data);
                    }
                }
            }
        }
        Collections.sort(datas,new DataCount());
        if(datas.size()>0){
            Data data = datas.get(0);
            if(data.getCount() == 100){
                return true;
            }
        }
        return false;
    }

    //电脑通过计算走下一步
    private static boolean go(GamePanel panel) {
        List<Data> datas = new ArrayList<Data>();
        Pointer[][] pointers = panel.pointers;
        //循环指示器
        Pointer pointer;
        Data data;
        for(int i=0;i<panel.ROWS;i++)
        {
            for(int j=0;j<panel.CLOS;j++)
            {
                pointer = pointers[i][j];
                if(pointer==null || pointer.getType() == 0){
                    continue;
                }
                    int dir = 0;
                    for(int k = 1;k<=4;k++) {
                        dir = k;
                        //获取权重1
                        data = getData(dir ,1,panel,pointer);
                        System.out.println(data.getCount());
                        if(data.getCount() !=0 && data.getCount() != -1){

                            datas.add(data);
                        }
                        //获取权重分2
                        data = getData(dir,2,panel,pointer);
                        if(data.getCount() != 0 && data.getCount() != -1){
                            //添加到集合中
                            datas.add(data);
                        }


                }
            }
        }
        Collections.sort(datas,new DataCount());//排序
        for(int i=0;i<datas.size();i++)
        {
            System.out.println("权重分"+datas.get(i).getCount());
        }

        if(datas.size()>0){
            Data data2 = datas.get(0);
            Pointer pointer1 = pointers[data2.getI()][data2.getJ()];
            luozi(pointer1,1,panel);

            return true;
        }
        return false;
    }
    //计算获取权重分
    private static Data getData(int dir, int type,GamePanel panel, Pointer pointer) {
        //返回结果
        Data resData = new Data();
        int i = pointer.getI();
        int j = pointer.getJ();
        Pointer [][] pointers = panel.pointers;
        Pointer temPointer;
        int num = 1;//计算分数
        int num2 = 1;//累计相同
        boolean breakFlag = false;//是否中断
        boolean lClose = false;//左边关闭
        boolean rClose = false;//右边关闭
        if(dir == 1){
            //从左到右
            if(type == 1){
                for(int k = j+1;k<panel.CLOS;k++){
                    temPointer = pointers[i][k];//拿到循环元素（指示器）
                    if(temPointer.getType() == pointer.getType()){ //连续
                        num++;
                        num2++;
                        if(k == panel.CLOS-1){
                            rClose = true;
                        }
                    }else if(temPointer.getType() == 0){//如果是空
                        if(breakFlag){
                            //判断前一个子是否空白
                            if(pointers[i][k-1].getType() == 0){//如果空白
                                breakFlag = false;
                            }
                            break;
                        }
                        num++;
                        breakFlag = true;
                        resData.setI(i);
                        resData.setJ(k);
                    }else{//对立，不同颜色
                        rClose = true;
                        break;
                    }

                    //处理左边关闭
                    if(j == 0){
                        lClose = true;
                    }else{
                        if(pointers[i][j-1].getType() != 0){
                            lClose = true;
                        }
                    }

                }
            }else{//从右往左

                for(int k = j-1;k>=0;k--){
                    temPointer = pointers[i][k];//拿到循环元素（指示器）
                    if(temPointer.getType() == pointer.getType()){ //连续
                        num++;
                        num2++;
                        if(k == 0){
                            lClose = true;
                        }
                    }else if(temPointer.getType() == 0){//如果是空
                        if(breakFlag){
                            //判断前一个子是否空白
                            if(pointers[i][k+1].getType() == 0){//如果空白
                                breakFlag = false;
                            }
                            break;
                        }
                        num++;
                        breakFlag = true;
                        resData.setI(i);
                        resData.setJ(k);
                    }else{//对立，不同颜色
                        lClose = true;
                        break;
                    }

                    //处理右边关闭
                    if(j == panel.CLOS-1){
                        rClose = true;
                    }else{
                        if(pointers[i][j-1].getType() != 0){
                            rClose = true;
                        }
                    }

                }

            }
        }else if(dir == 2){
            if(type == 1){
                for(int k = i+1;k<panel.ROWS;k++){
                    temPointer = pointers[k][j];
                    if(temPointer.getType() == pointer.getType()){//连续
                        num++;
                        num2++;
                        if(k == panel.ROWS-1){//左后一个连续，右边关闭
                            rClose = true;
                        }
                    }else if(temPointer.getType() == 0) {//null
                        if (breakFlag) {//有一个不通过
                            if (pointers[k - 1][j].getType() == 0) {
                                breakFlag = false;
                            }
                            break;
                        }
                        num++;
                        if (k == 0 || k == panel.ROWS - 1) {
                            break;
                        }
                        breakFlag = true;
                        //食终端那种，设定落子位置
                        resData.setI(k);
                        resData.setJ(j);

                    }else{//对立右边关闭
                        rClose = true;
                        break;
                    }
                }
                //判读左边关闭
                if(i == 0){//当前为最左边子
                    lClose = true;
                }else{
                    temPointer= pointers[i-1][j];
                    if(temPointer.getType() != 0){//如果左边有子，关闭
                        lClose = true;
                }
            }

        }else{
                for(int k = i-1;k>=0;k--){
                    temPointer = pointers[k][j];
                    if(temPointer.getType() == pointer.getType()){
                        num++;
                        num2++;
                        if(k == 0){
                            lClose = true;
                        }
                    }else if(temPointer.getType() == 0){
                        if(breakFlag){
                            if(pointers[k+1][j].getType() == 0){
                                breakFlag = false;
                            }
                            break;
                        }
                        breakFlag = true;
                        resData.setI(k);
                        resData.setJ(j);
                    }else{
                        lClose = true;
                        break;
                    }
                }
                //判断有关闭
                if(i==panel.ROWS-1){
                    rClose = true;
                }else{
                    temPointer = pointers[i+1][j];
                    if(temPointer.getType() != 0){
                        rClose = true;
                    }
                }
            }
        }else if(dir == 3){
            int tempi = i;
            if(type == 1){
                for(int k=j+1;k<panel.CLOS;k++){
                    tempi++;
                    if(tempi>panel.CLOS-1){//超粗边界
                        rClose = true;
                        break;
                    }
                    temPointer = pointers[tempi][k];
                    if(temPointer.getType() == pointer.getType()){//连续
                        num++;
                        num2++;
                        if(k == panel.CLOS-1){
                            rClose = true;
                        }
                    }else if(temPointer.getType() == 0){
                        if(breakFlag){//有一个不能通过
                            if(pointers[tempi-1][k-1].getType() == 0){//如果钱一个食空子，设置不中断
                                breakFlag = false;
                            }
                            break;
                        }
                        breakFlag = true;
                        resData.setI(tempi);
                        resData.setJ(k);
                    }else{//对立
                        rClose = true;
                        break;
                    }
                }
                //对立食做关闭
                if(j == 0||i == 0){
                    lClose = true;
                }else{
                    temPointer = pointers[i-1][j-1];
                    if((temPointer.getType() != 0)){
                        lClose = true;
                    }
                }
            }else{//从右往左
                for(int k=j-1;k>=0;k--){
                    tempi--;
                    if(tempi<0){
                        lClose = true;
                        break;
                    }
                    temPointer = pointers[tempi][k];
                    if(temPointer.getType() == pointer.getType()){//连续
                        num++;
                        num2++;
                        if(k == 0){
                            lClose = true;
                        }
                    }else if(temPointer.getType() == 0){
                        if(breakFlag){
                            if(pointers[tempi+1][k+1].getType() == 0){
                                breakFlag = false;
                            }
                            break;
                        }
                        breakFlag = true;
                        resData.setI(tempi);
                        resData.setJ(k);
                    }else{
                        lClose = true;
                        break;
                    }
                }
                //判断左关闭
                if(j==panel.CLOS-1||i == panel.ROWS-1){
                    rClose = true;
                }else{
                    temPointer = pointers[i+1][j+1];
                    if(temPointer.getType() != 0){
                        rClose = true;
                    }
                }
            }
        }else if(dir == 4){
            int tempi = i;
            if(type == 1){
                for(int k = j+1;k<panel.ROWS;k++){
                    tempi--;
                    if(tempi<0){
                        rClose = true;
                        break;
                    }
                    temPointer = pointers[tempi][k];
                    if(temPointer.getType()==pointer.getType()){
                        num++;
                        num2++;
                        if(k == panel.CLOS-1){
                            rClose = true;
                        }
                    }else if(temPointer.getType() == 0){//空白子
                        if(breakFlag){
                         if(pointers[tempi+1][k-1].getType() == 0){
                             breakFlag = false;
                         }
                         break;
                        }
                        num++;
                        if(tempi==0||tempi==panel.ROWS-1||k==0||k==panel.CLOS-1){
                            break;
                        }
                        breakFlag = true;
                        resData.setI(tempi);
                        resData.setJ(k);
                    }else{
                        rClose = true;
                        break;
                    }
                }
                //判断右边关闭
                if(j == 0||i == 0){
                    lClose = true;
                }else{
                    if(i == panel.ROWS-1){
                        lClose = true;
                    }else{
                        temPointer = pointers[i+1][j-1];
                        if(temPointer.getType() != 0){
                            lClose = true;
                        }
                    }
                }
            }else{//有望左
                for(int k=j-1;k>=0;k--){
                    tempi++;
                    if(tempi>panel.ROWS-1){
                        lClose = true;
                        break;
                    }
                    temPointer = pointers[tempi][k];
                    if(temPointer.getType() == pointer.getType()){
                        num++;
                        num2++;
                        if(k == 0){
                            lClose = true;
                        }
                    }else if(temPointer.getType() == 0){
                        if(breakFlag){
                            if(pointers[tempi-1][k+1].getType() == 0){
                                breakFlag = false;
                            }
                            break;
                        }
                        num++;
                        if(tempi==0||tempi==panel.ROWS-1||k==0||k==panel.CLOS-1){
                            break;
                        }
                        breakFlag = true;
                        resData.setI(tempi);
                        resData.setJ(k);
                    }else{//对立
                        lClose = true;
                        break;
                    }
                }
                //判断有关闭
                if(j == panel.CLOS-1||i == panel.ROWS-1){
                    rClose = true;
                }else{
                    if(i == 0){
                        rClose = true;
                    }else{
                        temPointer = pointers[i-1][j+1];
                        if(temPointer.getType() != 0){
                            rClose = true;
                        }
                    }
                }
            }
        }
        //设定分数
        setCount(resData,i,j,dir,type,num,num2,breakFlag,lClose,rClose,panel);

        return resData;
    }
    //设定分数方法
    private static void setCount(Data resData, int i,int j ,int dir ,int type,int num, int num2, boolean breakFlag, boolean lClose, boolean rClose, GamePanel panel) {
        //计的算分数
        int count = 0;
        if(num <= 2){
            return;
        }
        //分数初步设定
        if(num == 3){
            count = 30;
        }else if(num == 4){
            count = 40;
        } else if (num == 5) {
            count = 50;
        }
        //如果5子，设定分数100
        if(num2 >= 5 && !breakFlag){
            count=100;
            resData.setCount(100);
            return;
        }
        if(breakFlag){//如果中断
            if(lClose&&rClose){
                count = -1;
            }

        }else{
            //连续
            if(lClose && rClose){
                count = -1;
            }else if(!lClose){
                count += 2;
                //横向
                if(dir == 1){
                    //从左往右
                    if(type == 1){
                        resData.setI(i);
                        resData.setJ(j-1);
                    }else{
                        resData.setI(i);
                        resData.setJ(j-num+1);
                    }
                }else if(dir == 2){
                    if(type == 1){
                        resData.setI(i-1);
                        resData.setJ(j);
                    }else{
                        resData.setI(i-num+1);
                        resData.setJ(j);
                    }
                }else if(dir == 3){
                    if(type == 1){
                        resData.setI(i-1);
                        resData.setJ(j-1);
                    }else{
                        resData.setI(i-num+1);
                        resData.setJ(j-num+1);
                    }
                }else if(dir == 4){
                    if(type == 1){
                        resData.setI(i+1);
                        resData.setJ(j-1);
                    }else{
                        resData.setI(i+num-1);
                        resData.setJ(j-num+1);
                    }
                }

            }else if(!rClose){
                count += 1;
                //横向
                if(dir == 1){
                    //从左往右
                    if(type == 1){
                        resData.setI(i);
                        resData.setJ(j+num-1);
                    }else{
                        resData.setI(i);
                        resData.setJ(j+1);
                    }
                }else if(dir == 2){
                    if(type == 1){
                        resData.setI(i+num-1);
                        resData.setJ(j);
                    }else{
                        resData.setI(i+1);
                        resData.setJ(j);
                    }
                }else if(dir == 3){
                    if(type == 1){
                        resData.setI(i+num-1);
                        resData.setJ(j+num-1);
                    }else{
                        resData.setI(i+1);
                        resData.setJ(j+1);
                    }
                }else if(dir == 4){
                    if(type == 1){
                        resData.setI(i-num+1);
                        resData.setJ(j+num-1);
                    }else{
                        resData.setI(i-1);
                        resData.setJ(j+1);
                    }
                }
            }
        }
        resData.setCount(count);
    }

    //随机落子
    private static boolean louziRandom(GamePanel panel) {
        //随机获取指示器位置
        Pointer pointer = getRandomPointer(panel);
        //根据位置落子
        luozi(pointer,1,panel);
        return false;
    }
    private static void luozi(Pointer pointer, int type,GamePanel panel) {
        //创建棋子对象
        Qizi qizi = new Qizi(pointer.getX(),pointer.getY(),type);
        qizi.setLast(true);
        //将棋子添加到集合中
        panel.qizis.add(qizi);
        //设置类型
        pointer.setType(type);
        //重绘
        panel.repaint();

        if(has5(pointer,panel)){
            panel.gameOver();
        }

    }
    private static Pointer getRandomPointer(GamePanel panel) {
        Random random = new Random();
        int i = random.nextInt(panel.ROWS);//0-14
        int j = random.nextInt(panel.CLOS);//0-14
        //获取对应位置的指示器对象
        Pointer pointer= panel.pointers[i][j];
        if(pointer.getType() != 0){
            return getRandomPointer(panel);//递归
        }
        return pointer;
    }
}
//自定义排序类
class DataCount implements Comparator<Data>{

    @Override
    public int compare(Data o1, Data o2) {
        if(o1.getCount() > o2.getCount()){
            return -1;
        }
        return 1;
    }

}